#!/usr/bin/env rspec
require 'spec_helper'

require 'puppet/indirector/file_metadata'

describe "Puppet::Indirector::Metadata::Rest" do
  it "should add the node's cert name to the arguments"
end
